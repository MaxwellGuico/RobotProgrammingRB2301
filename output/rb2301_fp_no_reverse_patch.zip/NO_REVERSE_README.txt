NO-REVERSE CONTROLLER PATCH

Stop the old autonomous controller with Ctrl+C before updating.
Extract this archive at the robot workspace root (the directory containing src and fp.sh).
Only two source files are replaced. Optitrack/LiDAR configuration files are not replaced.

Then run:
colcon build --packages-select rb2301_fp --symlink-install
source install/setup.bash
./fp.sh --terminal-debug

Automatic reversing and its enable flag are removed. The controller can command forward motion,
collision-checked rotation, or stop. The safety checker rejects reverse commands and the publisher
clamps linear.x to zero or greater. Stalled motion stops; there is no reverse-escape exception.
Planned panel pauses do not count as failed motion. The patch is Python 3.8 compatible and adds no libraries.

Validation: 81 unit tests pass, Python 3.8 syntax scan passes, and a 25-second Gazebo startup smoke
contained no negative forward commands. The previous three full-course passes used the old
reverse recovery; full course completion has not been revalidated after removing it.
