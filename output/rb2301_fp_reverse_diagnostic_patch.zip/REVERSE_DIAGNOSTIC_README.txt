Extract this archive at the robot workspace root (the directory containing src and fp.sh).
Only obstacle_course.py and gap_navigation.py are included. Configuration files are unchanged.
Stop the currently running autonomous controller first, then run:

colcon build --packages-select rb2301_fp --symlink-install
source install/setup.bash
./fp.sh --terminal-debug --ros-args -p enable_reverse_recovery:=false

With this startup parameter, this controller stops after detecting a stall instead of entering reverse recovery.
Collision checks remain active. This is a diagnostic mitigation; it does not establish the underlying sensor/pose fault.
Copy the Navigation stalled diagnostic line, including motion_status, inside_points and ages_s.
The patch also includes the Python 3.8-compatible Optional annotation.
